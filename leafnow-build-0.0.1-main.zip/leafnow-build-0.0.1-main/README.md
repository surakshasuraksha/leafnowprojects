This is a full stack development internship project on title named LEAF NOW which serves as a common platform for buying/selling/donating of plants/seeds.
